import javafx.application.Application;//import statements to run javafx
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;
public class GUI extends Application{//GUI class
    public void start(Stage PrimaryStage) {//overriding the start method
        Button add_attendee = new Button("Add attendee");//creating button to add attendees
        Button clear = new Button("Clear");//creating button to clear all the data
        Button add_workshop = new Button("Add workshop");//creating button to form a workshop
        Button remove_attendee = new Button("Remove Attendee");//creating button to remove attendees
        Button display = new Button("Display");//creating button to display all the data
        TextField tf1 = new TextField("Passport");//text field to write the passport of attendees
        TextField tf2 = new TextField("Attendee name");//text field to write the attendees names
        TextField tf3 = new TextField("Workshop name");////text field to write the workshop names
        TextArea tf4 = new TextArea();//text area to display all the data
        Label lb1 = new Label("Passport:");//labels that indicate which text field is which
        Label lb2 = new Label("Attendee name:");
        Label lb3 = new Label("Workshop name:");
        tf4.setPrefColumnCount(60);//setting the height and width of the text area
        tf4.setPrefHeight(150);
        tf4.setEditable(false);//making the text area where the data would be displayed non-editable
        ChoiceBox<String> ch = new ChoiceBox<String>();//drop down menu to see the existing workshops
        ch.getItems().add("Select workshop");//setting the default value of the drop down menu
        ch.setValue("Select workshop");
        GridPane grid = new GridPane();//secondary pane
        FlowPane pane = new FlowPane();//main pane
        pane.setAlignment(Pos.BASELINE_CENTER);//aligning the pane
        pane.getChildren().add(grid);//adding items to panes
        pane.getChildren().add(tf4);
        pane.setVgap(150);//setting the gap between each node
        pane.setHgap(6);
        HBox box = new HBox();//horizontal box to host the buttons
        box.getChildren().add(add_attendee);//adding the buttons to the HBox
        box.getChildren().add(add_workshop);
        box.getChildren().add(remove_attendee);
        box.getChildren().add(clear);
        box.getChildren().add(display);
        box.setSpacing(6);
        grid.setAlignment(Pos.TOP_LEFT);
        grid.setHgap(6);
        grid.setVgap(5);
        String Z[] = MainOperation.ReadFromFile();//reading the external file to add workshops
        for(int i=0;i<Z.length;i++)
        {
            ch.getItems().add(Z[i]);
            MainOperation.FormWorkshop(Z[i]);
        }

        grid.add(tf1, 0,1);//adding the labels and text fields to the secondary pane
        grid.add(tf2, 1,1);
        grid.add(tf3, 2,1);
        grid.add(lb1, 0,0);
        grid.add(lb2, 1,0);
        grid.add(lb3, 2,0);
        grid.add(ch,3,1);
        grid.add(box,0,3,4,1);


// setting the actions that happens when a button is clicked
        add_attendee.setOnAction(e ->
        {//when button add attendee is pressed
            tf4.setText(MainOperation.AddAttendee(tf3.getText(),tf2.getText(),tf1.getText()));//messages that show whether the operation was successful or not

        });
        add_workshop.setOnAction(e ->
        {//when button add workshop is pressed
            ch.getItems().add(tf3.getText());
            tf4.setText(MainOperation.FormWorkshop(tf3.getText()));//messages that show whether the operation was successful or not
        });

        remove_attendee.setOnAction(e ->
        {//when button remove is pressed
            tf4.setText(MainOperation.RemoveAttendee(tf3.getText(),tf2.getText(),tf1.getText()));//messages that show whether the operation was successful or not
        });
        clear.setOnAction(e ->
        {//clearing all forms of input
            tf1.setText("");
            tf2.setText("");
            tf3.setText("");
            tf4.setText("");
            ch.getItems().removeAll();


        });
        display.setOnAction(e ->
        {//when button display is pressed

            tf4.appendText(MainOperation.display());
            System.out.println(MainOperation.display());//displaying all data


        });
        ch.setOnAction(e->
        {//when choosing a workshop from the dropdown menu
            tf3.setText(ch.getValue());
        });


        Scene scene = new Scene(pane, 750, 600);//creating the scene and stage
        PrimaryStage.setTitle("Workshop Manager");
        PrimaryStage.setScene(scene);
        PrimaryStage.show();//launching the stage
    }
}

