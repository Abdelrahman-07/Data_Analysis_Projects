import java.util.Set;//import statements to use the sets
import java.util.TreeSet;

public class Workshop implements Comparable <Workshop> {//the workshop class implements the comparable interface
    //attributes for each workshop
    private Set<Attendee> attendees = new TreeSet<Attendee>();// each workshop has a list of attendees
    private String name;// each workshop has a name


    public Workshop() {//workshops empty constructor
    }

    public Workshop(String name) {//Workshops constructor with attributes
        this.name = name;
    }


    //getter and setter methods to get and set the list of attendees in each workshop
    public Set<Attendee> getAttendees() {
        return attendees;
    }

    public void setAttendees(Set<Attendee> attendees) {
        this.attendees = attendees;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }



    @Override//overriding the toString method
    public String toString() {
        for (Attendee X: this.getAttendees()) {

            System.out.println(X.toString());
        }
        return "";
    }

    @Override//overriding the compareTo method from the comparable interface
    public int compareTo(Workshop o) {
        return this.getName().compareTo(o.getName());
    }

    @Override
    public boolean equals(Object obj) {//overriding the equals method to compare workshops based on their name
        if (this.getName().equals(((Workshop) obj).getName())) {
            return true;
        } else {
            return false;
        }
    }
}
