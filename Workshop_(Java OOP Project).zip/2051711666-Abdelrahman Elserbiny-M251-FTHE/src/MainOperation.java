import java.util.*;//import statements to use the file and scanner class
import java.io.*;


public class MainOperation {//the class the handles the data and operations
    public MainOperation() {
    }

    //attributes of the operation class
    public static Set<Workshop> workshops = new TreeSet<Workshop>();//list of workshops
    static int clue = 0;//arbitrary indicator to error check
    public static String FormWorkshop(String V) {//static method to create new workshops
        Workshop p = new Workshop();

        for (Workshop X : workshops) {//for loop to check if the workshop exists or if the workshop name is suitable
            if(V.isEmpty())
            {//if statement to check whether the workshop name is suitable
                System.out.println("Enter a suitable name");
                return "Enter a suitable name";//return statements for the gui class
            }
            if (X.getName().equals(V)) {//looking if another workshop has a matching name

                System.out.println("workshop " + V + " already exists");
                clue = 1;//indication to determine if the workshop is in the list or not
                return "workshop " + V + " already exists";
            } else {
                clue = 0;
            }

        }
        if (clue == 0) {//checking if workshop is unique
            p = new Workshop(V);//creating a workshop
            workshops.add(p);//adding the workshop to the list of workshops
            System.out.println("Workshop " + V + " has been formed");
            return "Workshop " + V + " has been formed";

        }
        return "";
    }


    public static String AddAttendee (String V,String y,String x)
    {//method to add attendees
        Attendee k = new Attendee();//creating an attendee variable to assign the attributes to it
        int clue3 = 0;//clue to know if a workshop exists
        k = new Attendee(y, x);
        Workshop a = new Workshop(V);

        for (Workshop R : workshops) {//iterating over the workshops
            if (R.getName().equals(V)) {//checking if a workshop with matching attributes exists
                clue3 = 1;
                a = R; //saving the workshop to another variable

                if (a.getAttendees().size() == 0)
                {//checking if the workshop is empty
                    a.getAttendees().add(k);
                    System.out.println(y+" has been added to Workshop "+V);
                    return y+" has been added to Workshop "+V;

                }
                else  if(a.getAttendees().size() > 0){
                    for (Attendee X : a.getAttendees()) {//iterating over the attendees in the chosen workshop
                        if (X.getPassport().equals(x)) {//checking if the attendee is already in the workshop

                            System.out.println(y+" is already in workshop "+V);
                            clue = 1;
                            return y+" is already in workshop "+V;


                        }
                        else {
                            clue = 0;
                        }

                    }
                    if (clue == 0)//checking the clue to decide whether to add the attendee or not
                    {
                        a.getAttendees().add(k);
                        System.out.println(y+" has been added to Workshop "+V);
                        return y+" has been added to Workshop "+V;

                    }
                }
            }
        }
        if (clue3 == 0) {//checking the clue to see if the workshop exists
            System.out.println("Workshop "+V+" does not exist");
            return "Workshop "+V+" does not exist";
        }
        return "";

    }


    public static String RemoveAttendee (String V,String y,String x)
    {//method to remove an attendee
        Attendee k;
        Workshop a = new Workshop(V);
        int clue3 = 0;//clue to know if a group exists


        k = new Attendee(y, x);

        for (Workshop R : workshops) {
            if (R.getName().equals(V)) {//checking if a workshop with the inputted attributes exists
                clue3 = 1;//indicating the workshop exists
                a = R;
                if (a.getAttendees().size() == 0) {//checking if the workshop is empty
                    System.out.println("the workshop is empty");
                    return "the workshop is empty";
                }
                else
                {//iterating over the attendees to see if the wanted attendee is in the workshop
                    for (Attendee X : a.getAttendees()) {

                        if (X.getPassport().equals(x) ) {
                            clue = 0;
                            break;
                        }
                        else
                        {
                            clue = 1;
                        }

                    }

                    if (clue == 0) {//removing the attendee if the clue matches
                        a.getAttendees().remove(k);
                        System.out.println(y+" has been removed from Workshop "+V);
                        return y+" has been removed from Workshop "+V;

                    }
                    else if (clue == 1)
                    {
                        System.out.println(y+" is not in Workshop "+V);
                        return y+" is not in Workshop "+V;
                    }
                }

            }

        }
        if (clue3 == 0) {//checking if the workshop does not exist

            System.out.println(" Workshop "+V+" does not exist");
            return" Workshop "+V+" does not exist";

        }
        return "";
    }



    public static String PrintWorkshops () {//method to print sorted data
        try {//try and catch statement to prevent array related errors such as accessing a null element or an index out of the array
            int z=0;
            if(workshops.size()==0)
            {//checking if there are any workshops
                System.out.println("There are no workshops");
                return "There are no workshops";
            }
            Workshop[] workshop= new Workshop[workshops.size()];
            workshops.toArray(workshop);//making an identical array to the workshops list
            for (int i = 0; i < workshop.length; i++) {// for loop to sort the attendees based on their passports
                sortAttendees(workshop[i]);
            }
            //printing the sport of the first group and adding it to a text file
            if (workshops.size() == 1) {//checking if there is only one workshop
                System.out.print(workshop[0].getName() + ": \n");//printing the data
                System.out.println(workshops.toString());
                return workshop[0].getName() + ": \n"+workshops.toString();
            }
            for (int i = 0; i < workshop.length; i++) {//iterating over the workshops in the array and printing the data
                System.out.print(workshop[i].getName() + ": \n");
                System.out.print(workshop[i].toString() + " \n");


            }

        } catch (NullPointerException e) {
            System.out.println("Null pointer error. try checking the size of the array");
        } catch (IndexOutOfBoundsException j) {
            System.out.println("the index is out of bounds. try checking the size of the array");

        }
        return "";

    }
    private static String []a;//array to save the groups in the text file
    public static String[] ReadFromFile()//reading the workshops from a file
    {
        try
        {
            String Line,workshop;
            Set<String>WorkNames=new TreeSet<String>();//tree set to sort the names alphabetically
            //file directory
            File fw = new File("C:\\Users\\Abdelrahman\\IdeaProjects\\2051711666-Abdelrahman Elserbiny-M251-FTHE\\workshop.txt");
            Scanner sc = new Scanner(fw);
            while (sc.hasNextLine())//checking if there is information in the file
            {
                Line = sc.nextLine();
                if(!Line.startsWith("Name")&&!Line.startsWith("Passport")&&!Line.startsWith(" "))
                {//if statement to make sure the names the program saves are workshop names only
                    workshop = Line;
                    WorkNames.add(workshop);//adding it to a separate collection
                    Workshop i = new Workshop(Line);//adding it to the main collection
                    workshops.add(i);
                }

            }
            System.out.println(WorkNames);//printing the array of names

            sc.close();//closing the scanner
            a= new String[WorkNames.size()];//putting the names into an array for the gui class
            int i=0;

            for (String s:WorkNames) {
                a[i] = s;
                i++;

            }

        }
        catch(FileNotFoundException e)
        {
            System.out.println("the file is not found");
        }
        return a;

    }
    public static void sortAttendees(Workshop w)
    {//method for sorting the attendees based on their passport
        Attendee tmp = new Attendee();
        Attendee[] A = new Attendee[w.getAttendees().size()];
        w.getAttendees().toArray(A);
        for (int i = 0; i < A.length; i++) {//nested for loop to sort the workshops
            for (int j = i + 1; j < A.length; j++) {
                if (A[j].getPassport().compareTo(A[i].getPassport())<0) {
                    tmp = A[j];
                    A[j] = A[i];
                    A[i] = tmp;
                }

            }
        }

    }
    public static String display()
    {//method to display the data in th gui window
        String f = new String("");
        for (Workshop s:MainOperation.workshops) {//for loop to put the data into a string variable
            f = "\n"+f+ s.getName()+":\n";
            for (Attendee a:s.getAttendees()) {

                f = f+"Name: "+a.getName()+" , Passport: "+a.getPassport()+"\n";
            }
        }
        return f;//returning the full data
    }
}
