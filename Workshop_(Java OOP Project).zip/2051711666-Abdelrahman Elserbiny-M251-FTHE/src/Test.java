import java.util.Set;
import java.util.TreeSet;

public class Test {//the testing class
    public static void main(String[] args)
    {//main method
        MainOperation.FormWorkshop("omega");
        MainOperation.ReadFromFile();//reading workshop names from a file
       MainOperation.FormWorkshop("alpha");//creating workshops

       MainOperation.AddAttendee("alpha","ahmed","122341");//assigning attendees to workshops
        MainOperation.AddAttendee("alpha","shadi","0224324");
        MainOperation.AddAttendee("alpha","fadi","167897");
        MainOperation.AddAttendee("omega","helal","1678687");
        MainOperation.AddAttendee("omega","bassem","126867");
        MainOperation.AddAttendee("omega","rageh","1268674");
        MainOperation.AddAttendee("alpha","ahmed","35231");
        MainOperation.RemoveAttendee("alpha","fadi","167897");//removing attendees from a workshop
        //error checking
        MainOperation.RemoveAttendee("omega","fadi","167897");//removing an attendee from a different group
        MainOperation.RemoveAttendee("null","fadi","167897");//removing an attendee from a non-existing group
        MainOperation.AddAttendee("null","fadi","167897");//adding an attendee to a non-existing group
        MainOperation.AddAttendee("alpha","ahmed","122341");//assigning attendees to workshops
        MainOperation.PrintWorkshops();//printing the whole data
    }
}
