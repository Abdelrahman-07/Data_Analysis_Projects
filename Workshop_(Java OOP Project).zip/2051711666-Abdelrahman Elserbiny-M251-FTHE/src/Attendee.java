public class Attendee implements Comparable<Attendee> {//class for attendees
    //attributes of an attendee:
    private String name,Passport;
    private int phone,age;
    Attendee()//zero arg constructor
    {

    }
    Attendee(String n , String Pass)//constructor to make instances
    {
        Passport = Pass;
        name = n;
    }

    public String getPassport() {
        return Passport;
    }//getter and setter for the passport

    public void setPassport(String passport) {
        Passport = passport;
    }

    public String getName() {
        return name;
    }//getter and setter for the name

    public void setName(String name) {
        this.name = name;
    }


    public int getPhone() {
        return phone;
    }//getter and setter for the phone number

    public void setPhone(int phone) {
        this.phone = phone;
    }

    public int getAge() {
        return age;
    }//getter and setter for the attendee's age

    public void setAge(int age) {
        this.age = age;
    }

    @Override//overriding the toString method
    public String toString() {
        return "Name: " + this.getName() + ", Passport: " + this.getPassport() ;
    }

    @Override//overriding the compareto method
    public int compareTo(Attendee o) {
        return this.getPassport().compareTo(o.getPassport());
    }
}

